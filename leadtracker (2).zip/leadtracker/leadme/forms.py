from django import forms
from leadme.models import Register

class Register_ModelForm(forms.ModelForm):
	class  Meta:
		model=Register
		fields="__all__"