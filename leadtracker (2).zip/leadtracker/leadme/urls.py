from django.urls import path
from leadme import views
urlpatterns = [
    path('home/',views.home,name='home'),
    path('register_html/',views.register_html,name='register_html'),
    path('walkins/',views.walkins,name='walkins'),
    path('data_html/',views.data_html,name='data_html'),
	path('calling/',views.calling,name="calling"), 
    path('counselling/',views.counselling,name="counselling"),
    path('joining/',views.joining,name="joining"),
    path('callinghost/',views.callinghost,name='callinghost'),
    path('counsellinghost/',views.counsellinghost,name="counsellinghost"),
    path('currentstatus/',views.currentstatus,name="currentstatus"),
    path('Dead/<id>',views.Dead,name='Dead'),
    path('Willing/<id>',views.Willing,name='Willing'),
    path('edit/<id>',views.edit,name='edit'),
    path('students/',views.students,name='students'),
    path('complete/<id>',views.complete,name='complete'),
    path('delay/<id>',views.delay,name='delay'),
    path('rejoin/<id>',views.rejoin,name='rejoin'),

]
    
