from django.apps import AppConfig


class LeadmeConfig(AppConfig):
    name = 'leadme'
